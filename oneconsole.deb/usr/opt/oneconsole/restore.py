import sys,subprocess

rulesfile = "/usr/opt/oneconsole/rules.txt"


def main():
	with open(rulesfile) as file:
		for line in file:
			command = "sudo iptables "+line.strip('\n')
			sub = subprocess.call(command,shell=True)
		return


if __name__ == '__main__':
	main()