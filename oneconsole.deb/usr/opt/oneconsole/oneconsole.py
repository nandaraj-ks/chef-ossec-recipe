import socket,ssl,os,logging,logging.handlers
import sys,subprocess

##sudo iptables -I INPUT 3 -s 192.168.61.61 -j DROP

pid = str(os.getpid())
pidfile = "/var/run/oneconsole.pid"

rulesfile = "/usr/opt/oneconsole/rules.txt"

if os.path.isfile(pidfile):
	os.remove(pidfile)
file(pidfile,'w').write(pid)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#create file handler

handler = logging.handlers.RotatingFileHandler('/usr/opt/oneconsole/logs/oneconsole.log',maxBytes=1000*100,backupCount=5)
handler.setLevel(logging.INFO)

#create a logging format

formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s]  %(message)s')
handler.setFormatter(formatter)

#add the handler to the logger

logger.addHandler(handler)


def get_host_ip():
	host_name = ([(s.connect(('8.8.8.8', 80)), s.getsockname()[0], s.close()) \
		for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1])
	return host_name
host = ""
port = 9856
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind((host,port))
s.listen(5)
def do_something(connstream, data):
    temp_data = data
    data = data.split(',')
    allowed_ip_list = [get_host_ip(),'127.0.0.1','127.0.0.0']
    if len(data) == 2:
	    if data[1] not in allowed_ip_list:
		    if data[0] == 'block':
		    	rule_obj = open(rulesfile,"a+")
			c1 = "sudo iptables "
			c2 = "-I INPUT 1 -s "+data[1]+" -j DROP"
		    	command = c1+c2
		    	sub = subprocess.call(command,shell=True)
		    	connstream.write("success")
		    	rule_obj.write(c2+"\n")
		    	rule_obj.close()
		    elif data[0] == 'allow':
		    	command = "sudo iptables -D INPUT -s "+data[1]+" -j DROP"
		    	sub = subprocess.call(command,shell=True)
		    	connstream.write("success")
		    	rule_obj = open(rulesfile,"r")
		    	lines = [x.strip('\n') for x in rule_obj.readlines()]
		    	rule_obj.close()
		    	for x in lines:
		    		if data[1] in x.split():
		    			lines.remove(x)
		    			break
		    	rule_obj = open(rulesfile,"w")
		    	for line in lines:
		    		rule_obj.write(line+'\n')
		    	rule_obj.close()
		    else:
		    	connstream.write("fail")
	    else:
	    	connstream.write("fail")
	    	# connstream.write("white listed ips cannot be blocked")
    return False
def deal_with_client(connstream):
    data = connstream.read()
    while data:
        if not do_something(connstream, data):
            break
        data = connstream.read()

while True:
	try:
		newsocket, fromaddr = s.accept()
		connstream = ssl.wrap_socket(newsocket,
	                                 server_side=True,
	                                 certfile="/usr/opt/oneconsole/certificates/server.crt",
	                                 keyfile="/usr/opt/oneconsole/certificates/server.key")
		deal_with_client(connstream)
	except Exception as e:
		print e
		logger.error(e)